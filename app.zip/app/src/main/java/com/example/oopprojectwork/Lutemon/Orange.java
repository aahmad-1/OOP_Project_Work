package com.example.oopprojectwork.Lutemon;

public class Orange extends Lutemon {
    public Orange(String name) {
        super(name, 8, 1, 17,"orange");
    }

}
