package com.example.oopprojectwork.Lutemon;

public class Green extends Lutemon {
    public Green(String name) {
        super(name, 5, 2, 20,"green");
    }
}
