package com.example.oopprojectwork.Lutemon;

public class Red extends Lutemon {
    public Red(String name) {
        super(name, 3,4,5,"red");
    }
}
