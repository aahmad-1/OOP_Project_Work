package com.example.oopprojectwork;

import com.example.oopprojectwork.Lutemon.Black;
import com.example.oopprojectwork.Lutemon.Green;
import com.example.oopprojectwork.Lutemon.Lutemon;
import com.example.oopprojectwork.Lutemon.Orange;
import com.example.oopprojectwork.Lutemon.Pink;
import com.example.oopprojectwork.Lutemon.Red;

import java.util.ArrayList;

public class LutemonStorage {
    public static ArrayList<Lutemon> selectedForTraining = new ArrayList<>();
    public static ArrayList<Lutemon> selectedForBattle = new ArrayList<>();
    public static ArrayList<Lutemon> allLutemons = new ArrayList<>();


}
