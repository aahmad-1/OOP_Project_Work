package com.example.oopprojectwork.Lutemon;

public class Black extends Lutemon {
    public Black(String name) {
        super(name,5, 5, 12,"black");
    }

}
