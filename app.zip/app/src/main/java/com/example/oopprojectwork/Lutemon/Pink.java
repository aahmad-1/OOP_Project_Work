package com.example.oopprojectwork.Lutemon;

public class Pink extends Lutemon {
    public Pink(String name) {
        super(name, 7, 2, 18,"pink");
    }

}
